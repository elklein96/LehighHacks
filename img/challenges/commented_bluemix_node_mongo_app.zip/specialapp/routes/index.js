// A request for '/' will send the views/index.html file
exports.index = function(req, res){
  res.render('index.html', { title: 'Cloudant Boiler Plate' });
};
