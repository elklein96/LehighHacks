// As far as I can tell, this file is not in use
exports.list = function(req, res){
  res.send("respond with a resource");
};
