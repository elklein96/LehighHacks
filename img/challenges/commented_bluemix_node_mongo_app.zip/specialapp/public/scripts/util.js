// When the web app needs to interact with the server, it takes a few lines
// of code to prepare the appropriate request to the server, especially when
// we aren't using JQuery.  This file provides wrappers around the code for
// issuing requests to the server, so that we can make requests from app.js
// in fewer lines of code.

// Create an XMLHttpRequest object, which can then be used to send requests
// to the server.  The complexity of the code stems from it needing to create
// different types of objects depending on the browser.
//
// NB: This function is only used inside of this file
function createXHR(){
    if(typeof XMLHttpRequest != 'undefined'){
	return new XMLHttpRequest();
    }else{
	try{
	    return new ActiveXObject('Msxml2.XMLHTTP');
	}catch(e){
	    try{
		return new ActiveXObject('Microsoft.XMLHTTP');
	    }catch(e){}
	}
    }
    return null;
}

// Issue a GET request to the server.  GET requests are used to READ
// data.
function xhrGet(url, callback, errback){
    var xhr = new createXHR();
    xhr.open("GET", url, true);
    // when a response arrives, either call the callback, or the
    // error-callback, depending on the status of the reply.
    xhr.onreadystatechange = function(){
	if(xhr.readyState == 4){
	    if(xhr.status == 200){
		callback(parseJson(xhr.responseText));
	    }else{
		errback('service not available');
	    }
	}
    };
    // set a timeout on the request, issue an error message on timeout.
    xhr.timeout = 100000;
    xhr.ontimeout = errback;
    xhr.send();
}

// Issue a PUT request to the server.  PUT requests are used to UPDATE
// data.
//
// NB: see xhrGet for details
function xhrPut(url, data, callback, errback){
    var xhr = new createXHR();
    xhr.open("PUT", url, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function(){
	if(xhr.readyState == 4){
	    if(xhr.status == 200){
		callback();
	    }else{
		errback('service not available');
	    }
	}
    };
    xhr.timeout = 100000;
    xhr.ontimeout = errback;
    xhr.send(objectToQuery(data));
}

// Issue a POST request to the server, where the request includes a single
// data file.  POST requests are used to CREATE a new data item on the
// server.
//
// NB: see xhrGet for details
function xhrAttach(url, data, callback, errback)
{
    var xhr = new createXHR();
    xhr.open("POST", url, true);
    // NB: if we wanted to submit multiple files, or files AND data at the
    // same time, we'd need a header like this:
    //
    // xhr.setRequestHeader("Content-type", "multipart/form-data");
    xhr.onreadystatechange = function(){
	if(xhr.readyState == 4){
	    if(xhr.status == 200){
		callback(parseJson(xhr.responseText));
	    }else{
		errback('service not available');
	    }
	}
    };
    xhr.timeout = 1000000;
    xhr.ontimeout = errback;
    xhr.send(data);
}

// Issue a POST request to the server, where the content does not include any
// FILE data.
//
// NB: see xhrGet for details.
function xhrPost(url, data, callback, errback){
    var xhr = new createXHR();
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function(){
	if(xhr.readyState == 4){
	    if(xhr.status == 200){
		callback(parseJson(xhr.responseText));
	    }else{
		errback('service not available');
	    }
	}
    };
    xhr.timeout = 100000;
    xhr.ontimeout = errback;
    // turn the data into a query string and send it
    xhr.send(objectToQuery(data));
}

// Issue a DELETE request to the server.  DELETE requests are used to DELETE
// a data item on the server.
//
// NB: see xhrGet for details.
function xhrDelete(url, callback, errback){	
    var xhr = new createXHR();
    xhr.open("DELETE", url, true);
    xhr.onreadystatechange = function(){
	if(xhr.readyState == 4){
	    if(xhr.status == 200){
		callback();
	    }else{
		errback('service not available');
	    }
	}
    };
    xhr.timeout = 100000;
    xhr.ontimeout = errback;
    xhr.send();
}

// Given a string that is expected to be in JSON format, turn it into a
// JavaScript object.  Since we're not using JQuery, we need this function in
// order to be cross-browser compatible.
function parseJson(str){
    return window.JSON ? JSON.parse(str) : eval('(' + str + ')');
}

// Given a map of key/value pairs, format the data as a query string, with
// each piece encoded so that the data is easy to turn back into a map when
// it reaches the server.
function objectToQuery(map){
    var enc = encodeURIComponent, pairs = [];
    for(var name in map){
	var value = map[name];
	var assign = enc(name) + "=";
	if(value && (value instanceof Array || typeof value == 'array')){
	    for(var i = 0, len = value.length; i < len; ++i){
		pairs.push(assign + enc(value[i]));
	    }
	}else{
	    pairs.push(assign + enc(value));
	}
    }
    return pairs.join("&");
}

