// Since we have a single-page web app, index.html has all of the structure
// of the entire user interface.  This file has all of the code for
// describing how to get data to populate the table on the page, and for
// describing how to respond to button clicks to interact with the server to
// create/read/update/delete data on the server.

// app.js defines the data that we access as being accessible as
// http://server/api/favorites.  We code it up here, since it's a constant.
var REST_DATA = 'api/favorites';

// We need to listen for "ENTER" keystrokes... 13 is the keyboard code for
// "ENTER"
var KEY_ENTER = 13;

// This describes how to make a button for submitting a request to attach a
// file.
var attachButton = "<br><input type=\"file\" name=\"file\" id=\"upload_file\"><input width=\"100\" type=\"submit\" value=\"Upload\" onClick='uploadFile(this)'>";

// Now that we've defined our constants, let's define a bunch of functions.
// Note that at the bottom of this file, we'll actually RUN two of the
// functions, to initialize the application.

// When the app loads, this is responsible for loading the data from the
// server
function loadItems(){
    // Issue a request... when the data returns, the function (second
    // parameter) runs.
    xhrGet(REST_DATA, function(data){
	// stop showing loading message
	stopLoadingMessage();

	// We will store the data we get here
	var receivedItems = data || [];
        // We will validate the data, then put it here
	var items = [ ];
	// Make sure the received items have correct format
	for(var i = 0; i < receivedItems.length; ++i){
	    var item = receivedItems[i];
	    if(item && 'id' in item){
		items.push(item);
	    }
	}
        // Make sure items has a valid format, even if it's empty
	var hasItems = items.length;
	if(!hasItems){
	    items = [ ];
	}
        // put each item into the HTML page
	for(var i = 0; i < items.length; ++i){
	    addItem(items[i], !hasItems);
	}
        // if there weren't any items, then save all the data that is in
        // fields of the table, in case there were updates without
        // corresponding presses of ENTER
	if(!hasItems){
	    var table = document.getElementById('notes');
	    var nodes = [];
	    for(var i = 0; i < table.rows.length; ++i){
		nodes.push(table.rows[i].firstChild.firstChild);
	    }
	    if(nodes.length){
		saveChange(nodes.shift(), save);
	    }
	}
        },
        // If there is an error, run this code instead
        function(err){
	    console.error(err);
        });
}

// Put a message on the screen to show that the file is uploading
function startProgressIndicator(row) {	
    row.innerHTML="<td class='content'>Uploading file... <img height=\"50\" width=\"50\" src=\"images/loading.gif\"></img></td>";	
}

// Remove the message that shows the file is uploading
function removeProgressIndicator(row) {
    row.innerHTML="<td class='content'>uploaded...</td>";
}

// Add a new row to the <table>, and return it so that we can put content
// into it
function addNewRow(table) {
    var newRow = document.createElement('tr');
    table.appendChild(newRow);
    return table.lastChild;
}

// Send a file to the server
function uploadFile(node) {
    // Get the html element with the file name
    var file = node.previousSibling.files[0];
    
    // if file not selected, throw error
    if(!file)     {
	alert("File not selected for upload... \t\t\t\t \n\n - Choose a file to upload. \n - Then click on Upload button.");
	return;
    }

    // Get the row that has the file to upload
    var row = node.parentNode.parentNode;

    // Create a form, add the file to it
    var form = new FormData();
    form.append("file", file);

    // Get the row ID
    var id = row.getAttribute('data-id');

    // Put together the request to send to the server
    var queryParams = "id=" + (id==null?-1:id);
    queryParams+= "&name="+row.firstChild.firstChild.value;
    queryParams+="&value="+row.firstChild.nextSibling.firstChild.firstChild.firstChild.firstChild.firstChild.value;

    // Create a row into which we can put a progress indicator showing the
    // upload is still happening
    var table = row.firstChild.nextSibling.firstChild;	
    var newRow = addNewRow(table);	
    startProgressIndicator(newRow);

    // Actually send the data.
    xhrAttach(REST_DATA+"/attach?"+queryParams, form, function(item){
        // When the data is all sent, update the content of the row
	console.log('Item id - ' + item.id);
	console.log('attached: ', item);
	row.setAttribute('data-id', item.id);
	removeProgressIndicator(row);
	setRowContent(item, row);
    }, function(err){
	console.error(err);
    });
    
}

// Set the contents of an empty <tr> item (row), using "item"
function setRowContent(item, row) {
    // NB: you might want to do a console.log(item) to see what the data
    // looks like

    // Create a cell with a textarea
    var innerHTML = "<td class='content'><textarea id='nameText' onkeydown='onKey(event)'>"+item.name+"</textarea></td><td class='content'><table border=\"0\">";	

    // create another textarea for the description, and populate it if we
    // have data
    var valueTextArea = "<textarea id='valText' onkeydown='onKey(event)' placeholder=\"Enter a description...\"></textarea>";		
    if(item.value) {
	valueTextArea="<textarea id='valText' onkeydown='onKey(event)'>"+item.value+"</textarea>";
    }

    // Assemble the row element
    innerHTML+="<tr border=\"0\" ><td class='content'>"+valueTextArea+"</td></tr>";
    
    // put attachments into a new row
    var attachments = item.attachements;
    if(attachments && attachments.length>0) {
	// for each attachment, set it up based on the type of the attached
	// file.
	for(var i = 0; i < attachments.length; ++i){
	    var attachment = attachments[i];
	    if(attachment.content_type.indexOf("image/")==0)
	    {
		innerHTML+= "<tr border=\"0\" ><td class='content'>"+attachment.key+"<br><img width=\"200\" src=\""+attachment.url+"\" onclick='window.open(\""+attachment.url+"\")'></img></td></tr>" ;
	    } else if(attachment.content_type.indexOf("audio/")==0) {
		innerHTML+= "<tr border=\"0\" ><td class='content'>"+attachment.key+"<br><AUDIO  height=\"50\" width=\"200\" src=\""+attachment.url+"\" controls></AUDIO></td></tr>" ;
	    } else if(attachment.content_type.indexOf("video/")==0) {
		innerHTML+= "<tr border=\"0\" ><td class='content'>"+attachment.key+"<br><VIDEO  height=\"100\" width=\"200\" src=\""+attachment.url+"\" controls></VIDEO></td></tr>" ;
	    } else if(attachment.content_type.indexOf("text/")==0 || attachment.content_type.indexOf("application/")==0) {
		innerHTML+= "<tr border=\"0\" ><td class='content'><a href=\""+attachment.url+"\" target=\"_blank\">"+attachment.key+"</a></td></tr>" ;
	    } 
	}	
    }
    // add a delete button
    row.innerHTML = innerHTML+"</table>"+attachButton+"</td><td class = 'contentAction'><span class='deleteBtn' onclick='deleteItem(this)' title='delete me'></span></td>";
}

// This will add a new row to the table, for inserting new data
function addItem(item, isNew){
    var row = document.createElement('tr');
    row.className = "tableRows";
    var id = item && item.id;
    if(id){
	row.setAttribute('data-id', id);
    }
    if(item) { // if not a new row
	setRowContent(item, row);
    }
    else { //if new row
	row.innerHTML = "<td class='content'><textarea id='nameText' onkeydown='onKey(event)' placeholder=\"Enter a title for your favourites...\"></textarea></td><td class='content'><table border=\"0\"><tr border=\"0\"><td class='content'><textarea id='valText'  onkeydown='onKey(event)' placeholder=\"Enter a description...\"></textarea></td></tr></table>"+attachButton+"</td>" +
	    "<td class = 'contentAction'><span class='deleteBtn' onclick='deleteItem(this)' title='delete me'></span></td>";
    }

    var table = document.getElementById('notes');
    table.lastChild.appendChild(row);
    row.isNew = !item || isNew;
    
    if(row.isNew) {
	var textarea = row.firstChild.firstChild;
	textarea.focus();
    }
}

// When a delete button is pressed, this will delete the corresponding row
function deleteItem(deleteBtnNode){
    var row = deleteBtnNode.parentNode.parentNode;
    if(row.getAttribute('data-id')) {
	xhrDelete(REST_DATA + '?id=' + row.getAttribute('data-id'), function(){
	    row.remove();
	}, function(err){
	    console.error(err);
	});
    }	
}

// Whenever enter is pressed, this runs to determine if we need to update the
// server with the content of the corresponding textarea
function onKey(evt){
    if(evt.keyCode == KEY_ENTER && !evt.shiftKey){
	
	evt.stopPropagation();
	evt.preventDefault();
	var nameV, valueV;
	var row ; 		

        // prepare an object with the field name and value
	if(evt.target.id=="nameText") {
	    row = evt.target.parentNode.parentNode;
	    nameV = evt.target.value;
	    valueV = row.firstChild.nextSibling.firstChild.firstChild.firstChild.firstChild.firstChild.value ;
	    
	}
	else {
	    row = evt.target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
	    nameV = row.firstChild.firstChild.value;
	    valueV = evt.target.value;
	}
	var data = {
	    name: nameV,
	    value: valueV
	};			

        // If it's a new row, POST it
	if(row.isNew){
	    delete row.isNew;
	    xhrPost(REST_DATA, data, function(item){
		row.setAttribute('data-id', item.id);
	    }, function(err){
		console.error(err);
	    });
	}
        // otherwise PUT it
        else{
	    data.id = row.getAttribute('data-id');
	    xhrPut(REST_DATA, data, function(){
		console.log('updated: ', data);
	    }, function(err){
		console.error(err);
	    });
	}
	
	// move the focus to the next cell, or else make a new row and move
	// the focus there.
	if(row.nextSibling){
	    row.nextSibling.firstChild.firstChild.focus();
	}else{
	    addItem();
	}
    }
}

// Save changes to a row
function saveChange(contentNode, callback){
    // find the row, and get its data
    var row = contentNode.parentNode.parentNode;
    var data = {
	name: row.firstChild.firstChild.value,
	value:row.firstChild.nextSibling.firstChild.value		
    };

    // Is it a POST or a PUT?
    if(row.isNew){
	delete row.isNew;
	xhrPost(REST_DATA, data, function(item){
	    row.setAttribute('data-id', item.id);
	    callback && callback();
	}, function(err){
	    console.error(err);
	});
    }else{
	data.id = row.getAttribute('data-id');
	xhrPut(REST_DATA, data, function(){
	    console.log('updated: ', data);
	}, function(err){
	    console.error(err);
	});
    }
}

// There is a button on the screen for showing information about the app.
// When we click the button, this code will run and either show or hide that
// information.
function toggleAppInfo(){
    var node = document.getElementById('appinfo');
    node.style.display = node.style.display == 'none' ? '' : 'none';
}

// Put a nice-looking message on the screen to show that we're loading data
function showLoadingMessage() {
    document.getElementById('loadingImage').innerHTML = "Loading data "+"<img height=\"100\" width=\"100\" src=\"images/loading.gif\"></img>";
}

// Remove the "loading" message
function stopLoadingMessage() {
    document.getElementById('loadingImage').innerHTML = "";
}

// To initialize the application, show the loading message and then fetch the
// data.
showLoadingMessage();
loadItems();

