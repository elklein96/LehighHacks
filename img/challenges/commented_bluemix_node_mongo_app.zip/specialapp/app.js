// This file is "the server".  It has almost all of the code that describes
// how the server part of the app will work.  There are two main portions:
// code for serving static files (like index.html) and code for receiving
// requests that are sent via javascript on the client (i.e., after a button
// is pressed).

// Load a bunch of modules.  This is like "import" statements in Java.
var express = require('express'), routes = require('./routes'), user = require('./routes/user'), http = require('http'), path = require('path'), fs = require('fs');

// Our application uses the express framework
var app = express();

// set up variables related to the database
var db;
var cloudant;
var dbCredentials = {
    dbName : 'my_sample_db'
};

// Load a few more modules
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var logger = require('morgan');
var errorHandler = require('errorhandler');
var multipart = require('connect-multiparty')
var multipartMiddleware = multipart();

// Read the application configuration from the environment, and configure a
// few more modules
app.set('port', process.env.PORT || 3000);
// These say to use the 'ejs' template engine when serving files from the /views/ folder
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.use(logger('dev'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(methodOverride());

// These say to ship static files from /public, and for /views/style
app.use(express.static(path.join(__dirname, 'public')));
app.use('/style', express.static(path.join(__dirname, '/views/style')));

// development only
if ('development' == app.get('env')) {
    app.use(errorHandler());
}

// This code initializes the database connection by getting the configuration
// information from bluehost
function initDBConnection() {
    if(process.env.VCAP_SERVICES) {
	var vcapServices = JSON.parse(process.env.VCAP_SERVICES);
	// Pattern match to find the first instance of a Cloudant service in
	// VCAP_SERVICES. If you know your service key, you can access the
	// service credentials directly by using the vcapServices object.
	for(var vcapService in vcapServices){
	    if(vcapService.match(/cloudant/i)){
		dbCredentials.host = vcapServices[vcapService][0].credentials.host;
		dbCredentials.port = vcapServices[vcapService][0].credentials.port;
		dbCredentials.user = vcapServices[vcapService][0].credentials.username;
		dbCredentials.password = vcapServices[vcapService][0].credentials.password;
		dbCredentials.url = vcapServices[vcapService][0].credentials.url;
		cloudant = require('cloudant')(dbCredentials.url);
		
		// check if DB exists if not create
		cloudant.db.create(dbCredentials.dbName, function (err, res) {
		    if (err) { console.log('could not create db ', err); }
		});
		
		db = cloudant.use(dbCredentials.dbName);
		break;
	    }
	}
	if(db==null){
	    console.warn('Could not find Cloudant credentials in VCAP_SERVICES environment variable - data will be unavailable to the UI');
	}
    } else{
	console.warn('VCAP_SERVICES environment variable not set - data will be unavailable to the UI');
	// For running this app locally you can get your Cloudant credentials 
	// from Bluemix (VCAP_SERVICES in "cf env" output or the Environment 
	// Variables section for an app in the Bluemix console dashboard).
	// Alternately you could point to a local database here instead of a 
	// Bluemix service.
	//dbCredentials.host = "REPLACE ME";
	//dbCredentials.port = REPLACE ME;
	//dbCredentials.user = "REPLACE ME";
	//dbCredentials.password = "REPLACE ME";
	//dbCredentials.url = "REPLACE ME";
    }
}

// initialize the database
initDBConnection();

// Indicate that '/' should be served by the file in routes/index.js (see
// 'require' above)
app.get('/', routes.index);


// This helper function makes a JSON object with ID, name, and a set of
// attachments, so that we can send it to the HTML client
function createResponseData(id, name, value, attachments) {
    // set up the object
    var responseData = {
	id : id,
	name : name,
	value : value,
	attachements : []
    };
    
    // add the attachments to an array, with some extra metadata
    attachments.forEach (function(item, index) {
	var attachmentData = {
	    content_type : item.type,
	    key : item.key,
	    url : '/api/favorites/attach?id=' + id + '&key=' + item.key
	};
	responseData.attachements.push(attachmentData);
	
    });
    return responseData;
}


// This helper function saves a document (text, not an attachment) that has
// been uploaded via the /api/favorites POST route
var saveDocument = function(id, name, value, response) {
    if (id === undefined) {
	id = '';
    }
    // insert information into the database
    db.insert({
	name : name,
	value : value
    }, id, function(err, doc) {
	if(err) {
	    console.log(err);
	    response.sendStatus(500);
	} else
	    response.sendStatus(200);
	response.end();
    });
    
}

// This runs in response to a GET for /api/favorites/attach
app.get('/api/favorites/attach', function(request, response) {
    // get the document info from the query string
    var doc = request.query.id;
    var key = request.query.key;

    // get info from the database "attachment" table and send it back to the
    // client
    db.attachment.get(doc, key, function(err, body) {
        if (err) {
            response.status(500);
            response.setHeader('Content-Type', 'text/plain');
            response.write('Error: ' + err);
            response.end();
            return;
        }

        response.status(200);
        response.setHeader("Content-Disposition", 'inline; filename="' + key + '"');
        response.write(body);
        response.end();
        return;
    });
});

// This runs in response to a POST to create an entry in
// /api/favorites/attach
app.post('/api/favorites/attach', multipartMiddleware, function(request, response) {
    console.log("Upload File Invoked..");
    console.log('Request: ' + JSON.stringify(request.headers));

    // try to get the attachment from the database, so we can tell if this is
    // actually a file update
    var id;
    db.get(request.query.id, function(err, existingdoc) {		
	var isExistingDoc = false;
	if (!existingdoc) {
	    id = '-1';
	} else {
	    id = existingdoc.id;
	    isExistingDoc = true;
	}

	var name = request.query.name;
	var value = request.query.value;
	var file = request.files.file;
	var newPath = './public/uploads/' + file.name;		

	// this code will save the attachment to the filesystem
	var insertAttachment = function(file, id, rev, name, value, response) {
	    fs.readFile(file.path, function(err, data) {
		if (!err) {
		    if (file) {
			db.attachment.insert(id, file.name, data, file.type, {rev: rev}, function(err, document) {
			    if (!err) {
				console.log('Attachment saved successfully.. ');
	                        // now get the list of attachments and send
	                        // them all back to the client
				db.get(document.id, function(err, doc) {
				    console.log('Attachements from server --> ' + JSON.stringify(doc._attachments));
				    
				    var attachements = [];
				    var attachData;
				    for(var attachment in doc._attachments) {
					if(attachment == value) {
					    attachData = {"key": attachment, "type": file.type};
					} else {
					    attachData = {"key": attachment, "type": doc._attachments[attachment]['content_type']};
					}
					attachements.push(attachData);
				    }
				    var responseData = createResponseData(
					id,
					name,
					value,
					attachements);
				    console.log('Response after attachment: \n'+JSON.stringify(responseData));
				    response.write(JSON.stringify(responseData));
				    response.end();
				    return;
				});
			    } else {
				console.log(err);
			    }
			});
		    }
		}
	    });
	}

        // Use the above function to either update or create an attachment
        // file, and update or create an entry in the database corresponding
        // to that file
	if (!isExistingDoc) {
	    existingdoc = {
		name : name,
		value : value,
		create_date : new Date()
	    };
	    
	    // save doc
	    db.insert({
		name : name,
		value : value
	    }, '', function(err, doc) {
		if(err) {
		    console.log(err);
		} else {
		    
		    existingdoc = doc;
		    console.log("New doc created ..");
		    console.log(existingdoc);
		    insertAttachment(file, existingdoc.id, existingdoc.rev, name, value, response);
		    
		}
	    });
	} else {
	    console.log('Adding attachment to existing doc.');
	    console.log(existingdoc);
	    insertAttachment(file, existingdoc._id, existingdoc._rev, name, value, response);
	}
    });
});

// When a new data item (text) is sent to the server, this saves it to the database
app.post('/api/favorites', function(request, response) {

    console.log("Create Invoked..");
    console.log("Name: " + request.body.name);
    console.log("Value: " + request.body.value);
    var name = request.body.name;
    var value = request.body.value;
    saveDocument(null, name, value, response);
});

// Run this to delete a document
app.delete('/api/favorites', function(request, response) {
    console.log("Delete Invoked..");
    var id = request.query.id;
    // var rev = request.query.rev; // Rev can be fetched from request. if
    // needed, send the rev from client
    console.log("Removing document of ID: " + id);
    console.log('Request Query: '+JSON.stringify(request.query));
    db.get(id, { revs_info: true }, function(err, doc) {
	if (!err) {
	    db.destroy(doc._id, doc._rev, function (err, res) {
		// Handle response
		if(err) {
		    console.log(err);
		    response.sendStatus(500);
		} else {
		    response.sendStatus(200);
		}
	    });
	}
    });
});

// Handle an update of the text for a row of data
app.put('/api/favorites', function(request, response) {
    console.log("Update Invoked..");
    var id = request.body.id;
    var name = request.body.name;
    var value = request.body.value;
    console.log("ID: " + id);
    // we get first, to make sure the update is legal (the document must
    // exist)
    db.get(id, { revs_info: true }, function(err, doc) {
	if (!err) {
	    console.log(doc);
	    doc.name = name;
	    doc.value = value;
            // insert with the same doc.id to update
	    db.insert(doc, doc.id, function(err, doc) {
		if(err) {
		    console.log('Error inserting data\n'+err);
		    return 500;
		}
		return 200;
	    });
	}
    });
});

// Get all the rows of data in response to a GET at /api/favorites
app.get('/api/favorites', function(request, response) {
    console.log("Get method invoked.. ")
    
    db = cloudant.use(dbCredentials.dbName);
    var docList = [];
    var i = 0;
    db.list gets all the data
    db.list(function(err, body) {
	if (!err) {
	    var len = body.rows.length;
	    console.log('total # of docs -> '+len);
            // if there's no data, put a bogus document into the database
	    if(len == 0) {
		// push sample data
		// save doc
		var docName = 'sample_doc';
		var docDesc = 'A sample Document';
		db.insert({
		    name : docName,
		    value : 'A sample Document'
		}, '', function(err, doc) {
		    if(err) {
			console.log(err);
		    } else {
			
			console.log('Document : '+JSON.stringify(doc));
			var responseData = createResponseData(
			    doc.id,
			    docName,
			    docDesc,
			    []);
			docList.push(responseData);
			response.write(JSON.stringify(docList));
			console.log(JSON.stringify(docList));
			console.log('ending response...');
			response.end();
		    }
		});
	    }
            // Otherwise, get all the data, make a JSON object, and send it
            // to the client
            else {
                // get the attachments for each row of data
		body.rows.forEach(function(document) {
		    db.get(document.id, { revs_info: true }, function(err, doc) {
			if (!err) {
			    if(doc['_attachments']) {
				var attachments = [];
				for(var attribute in doc['_attachments']){
				    if(doc['_attachments'][attribute] && doc['_attachments'][attribute]['content_type']) {
					attachments.push({"key": attribute, "type": doc['_attachments'][attribute]['content_type']});
				    }
				    console.log(attribute+": "+JSON.stringify(doc['_attachments'][attribute]));
				}
				var responseData = createResponseData(
				    doc._id,
				    doc.name,
				    doc.value,
				    attachments);
				
			    } else {
				var responseData = createResponseData(
				    doc._id,
				    doc.name,
				    doc.value,
				    []);
			    }	
			    
			    docList.push(responseData);
			    i++;
			    if(i >= len) {
				response.write(JSON.stringify(docList));
				console.log('ending response...');
				response.end();
			    }
			} else {
			    console.log(err);
			}
		    });
		});
	    }
	} else {
	    console.log(err);
	}
    });
});

// This line actually starts our server, so that it can start handling
// requests.
http.createServer(app).listen(app.get('port'), '0.0.0.0', function() {
    console.log('Express server listening on port ' + app.get('port'));
});
