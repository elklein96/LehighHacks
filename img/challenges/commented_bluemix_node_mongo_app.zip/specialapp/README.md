# Node.js Cloudant Starter Overview

The Node.js Cloudant Starter demonstrates how to use the Bluemix Cloudant
NoSQL DB service. The app displays persisted files and lets the user upload
new files or delete old files.

## Decomposition Instructions

* See app.js for how to obtain and use the Cloudant credentials as well as
  the file CRUD API
* See public/scripts/index.js and public/scripts/util.js for how the
  front-end calls the back-end API

## Detailed Instructions

app.js contains most of the code for the server side of the application.  A
small amount of additional code is in routes/index.js and routes/user.js.

The application is configured to serve views/index.html as the main page of
the application.  views/index.html, in turn, uses public/scripts/util.js and
public/scripts/index.js to issue requests to the routes of the server
(app.js).

See the comments in those files for more information about how the
application behaves.
